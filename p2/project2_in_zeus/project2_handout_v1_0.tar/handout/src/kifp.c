/* Only Edit This File
 * ------------------
 *  Name: 
 *  GNumber: 
 */

#include <stdio.h>
#include <stdlib.h>
#include "common_structs.h"
#include "common_functions.h"
#include "kifp.h"

// Feel free to add many Helper Functions, Consts, and Definitions!

// ----------Public API Functions (write these!)-------------------

// toKifp - Converts a Number Struct (whole and fraction parts) into a KIFP Value
// number is managed by zuon, DO NOT FREE number.
// Return the KIFP Value on Success or -1 on Failure.
kifp_t toKifp(Number_t *number) {
  return -1;  // Replace this Line with your Code
}

// toNumber - Converts a KIFP Value into a Number Struct (whole and fraction parts)
// number is managed by zuon, DO NOT FREE or re-Allocate number. (It is already allocated)
// Return 0 on Success or -1 on Failure.
int toNumber(Number_t *number, kifp_t value) {
  return -1;  // Replace this Line with your Code
}

// mulKIFP - Multiplies two KIFP Values together using the Techniques from Class.
// - To get credit, you must work with S, M, and E components.
// - You are allowed to shift/adjust M and E to multiply whole numbers.
// Return the resulting KIFP Value on Success or -1 on Failure.
kifp_t mulKifp(kifp_t val1, kifp_t val2) {
  return -1;  // Replace this Line with your Code
}

// addKIFP - Adds two KIFP Values together using the Addition Techniques from Class.
// - To get credit, you must work with S, M, and E components.
// - You are allowed to shift/adjust M and E as needed.
// Return the resulting KIFP Value on Success or -1 on Failure.
kifp_t addKifp(kifp_t val1, kifp_t val2) {
  return -1;  // Replace this Line with your Code
}

// subKIFP - Subtracts two KIFP Values together using the Addition Techniques from Class.
// - To get credit, you must work with S, M, and E components.
// - You are allowed to shift/adjust M and E as needed.
// Return the resulting KIFP Value on Success or -1 on Failure.
kifp_t subKifp(kifp_t val1, kifp_t val2) {
  return -1;  // Replace this Line with your Code
}

// negateKIFP - Negates a KIFP Value.
// Return the resulting KIFP Value on Success or -1 on Failure.
kifp_t negateKifp(kifp_t value) {
  return -1;  // Replace this Line with your Code
}
